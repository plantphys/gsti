Loma Ridge Flux Tower Sites

PI: Michael Goulden

Sites: LRCS - Loma Ridge Coastal Sage
       LRCG - Loma Ridge Coastal Grassland


Gas Exchange Data: 

Artemisia samples need to be recalculated using correct chamber leaf area.
