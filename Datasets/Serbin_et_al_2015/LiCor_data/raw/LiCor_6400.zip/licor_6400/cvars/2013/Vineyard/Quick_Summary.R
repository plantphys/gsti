####################################################################################################
#
#  	--- Last updated:  9.27.2013 BY SPS
####################################################################################################


#---------------- Close all devices and delete all variables. -------------------------------------#
rm(list=ls(all=TRUE))   # clear workspace
graphics.off()          # close any open graphics
closeAllConnections()   # close any open connections to files

library(plotrix)
#--------------------------------------------------------------------------------------------------#


#---------------- *User defined settings.* --------------------------------------------------------#

### Input LI6400 dataset.  First define location of file (i.e. directory). 
in.dir <- '/Users/serbin/Data/Dropbox/NASA_HyspIRI_Project/Field_Data/LiCor_6400/CVARS/Vineyard/'
dataset <- 'Quick_Grape_Summary2.csv'

### Define input file to be processed
ge.data <- read.table(paste(in.dir,"/",dataset,sep=""), header=T,sep=",")
summary(ge.data)          ## Summary of dataset

in.dir <- '/Users/serbin/Data/Dropbox/NASA_HyspIRI_Project/Field_Data//Spectra//CVARS//Vineyard//'
spec.data <- 'Quick_Grape_Summary.csv'
spec.data <- read.table(paste(in.dir,"/",spec.data,sep=""), header=T,sep=",")
spec.data <- spec.data[,3:dim(spec.data)[2]]


out.dir <- '/Users/serbin/Data/Dropbox/PRESENTATIONS/AGU_2013/NASA_HyspIRI/Poster/Figs/'
#--------------------------------------------------------------------------------------------------#


#--------------------------------------------------------------------------------------------------#
# Fig
x <- cut(ge.data$CO2R,breaks=30,include.lowest=TRUE)
mean.ge.data <- aggregate(cbind(Photo,ETR,CO2R)~x, data=ge.data,mean)
sd.ge.data <- aggregate(cbind(Photo,ETR,CO2R)~x, data=ge.data,sd)
min.ge.data <- aggregate(cbind(Photo,ETR,CO2R)~x, data=ge.data,min)
max.ge.data <- aggregate(cbind(Photo,ETR,CO2R)~x, data=ge.data,max)

waves = seq(350,2500,1)
mn.refl = colMeans(spec.data)
min.refl = sapply(spec.data,min,simplify=TRUE)
max.refl = sapply(spec.data,max,simplify=TRUE)
sd.refl = sapply(spec.data,sd,simplify=TRUE)
#mn_refl_upper = mn_refl+sd_refl
#mn_refl_lower = mn_refl-sd_refl
spec.quant <- apply(spec.data,2,quantile,probs=c(0.05,0.95))

png(paste(out.dir,'NASA_HyspIRI_Grape_Photo_Summary_Figure.png',sep="/"),width=1500, height =2700,res=300)
par(mfrow=c(2,1), mar=c(4.3,4.5,0.5,0.8)) # B L T R

x <- c(50,100,250,400,900,1200,1500)
#plotCI(x,mean.ge.data[,2],uiw=sd.ge.data[,2],gap=0.009,sfrac=0.01,lwd=1.6,
#       err="y",pch=21,col="black",pt.bg="grey70",xlim=c(0,1500),cex=1.9,
#       ylim=c(0,40),xlab="Ci",ylab="Photosynthesis",main="",cex.axis=1.5,cex.lab=1.8)
plotCI(x,mean.ge.data[,2],li=min.ge.data[,2],ui=max.ge.data[,2],gap=0.009,sfrac=0.01,lwd=1.6,
       err="y",pch=21,col="black",pt.bg="grey70",xlim=c(0,1500),cex=1.9,
       ylim=c(-3,40),xlab="",ylab="Photosynthesis",main="",cex.axis=1.5,cex.lab=1.8)
legend("bottomright",legend="(a)",cex=2,bty="n")
box(lwd=2.2)


x <- c(50,100,250,400,900,1200,1500)
plotCI(x,mean.ge.data[,3],li=min.ge.data[,3],ui=max.ge.data[,3],gap=0.009,sfrac=0.01,lwd=1.6,
       err="y",pch=21,col="black",pt.bg="grey70",xlim=c(0,1500),cex=1.9,
       ylim=c(30,220),xlab="Ci",ylab="ETR",main="",cex.axis=1.5,cex.lab=1.8)
legend("bottomright",legend="(b)",cex=2,bty="n")
box(lwd=2.2)

dev.off()


plot(waves,mn.refl,xlim=c(350,2500),ylim=c(0.01,0.6),cex=0.00001, col="white",xlab="Wavelength (nm)",ylab="Reflectance (%)",
     cex.axis=1.5, cex.lab=1.7)
polygon(c(waves ,rev(waves)),c(max.refl, rev(min.refl)),col="#99CC99",border=NA)
lines(waves,mn.refl,lwd=4)
lines(waves,spec.quant[1,],lty=2,lwd=1.6)
lines(waves,spec.quant[2,],lty=2,lwd=1.6)
lines(waves,max.refl, lty=3, lwd=1)
lines(waves,min.refl, lty=3, lwd=1)
legend("topright",legend=c("Mean","95% CIs","Min / Max"),lty=c(1,2,3),
       lwd=c(2.2, 2.2, 2.2),bty="n", cex=1.7)
legend("bottomright",legend="(b)",cex=2,bty="n")
box(lwd=2.2)

dev.off()

#--------------------------------------------------------------------------------------------------#

